require('dotenv/config');
const path = require('path');

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || process.env.ALERT_TO || null;
const ALERT_FROM = process.env.ALERT_FROM || `no-reply@${process.env.APP_HOST || 'daftar.local'}`;
const SMTP = {
  host: process.env.SMTP_HOST || null,
  port: process.env.SMTP_PORT ? Number(process.env.SMTP_PORT) : null,
  user: process.env.SMTP_USER || null,
  pass: process.env.SMTP_PASS || null,
  secure: String(process.env.SMTP_SECURE || 'false') === 'true'
};

const DB_PATH = path.join(__dirname, 'dev.db');

module.exports = { ADMIN_EMAIL, ALERT_FROM, SMTP, DB_PATH };

// WhatsApp admin number (short number provided)
module.exports.ADMIN_WHATSAPP = process.env.ADMIN_WHATSAPP || '779992669';
